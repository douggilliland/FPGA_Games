variable data
: main
 h# f000 [char] H  swap c!
 data h# f005 c@
 h# f00A [char] H swap c!
	
 begin again

